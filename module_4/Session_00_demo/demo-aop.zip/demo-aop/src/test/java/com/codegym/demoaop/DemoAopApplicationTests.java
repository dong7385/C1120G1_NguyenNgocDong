package com.codegym.demoaop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAopApplicationTests {

    @Test
    void contextLoads() {
    }

}
